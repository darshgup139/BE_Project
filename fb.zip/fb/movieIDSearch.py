import tmdbsimple as tmdb
tmdb.API_KEY = '0fee9e05c566948369b71f0cb4e6cef6'


def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

len=file_len("newfile.txt")
print(len)

search = tmdb.Search()
f = open('newfile.txt', 'r')
for var in list(range(len)):
    movie_name=f.readline()
    response = search.movie(query=movie_name)
    data1=f.readline()
    a,b=data1.split(", ")
    c,d=b.split(" ")
    print("--------------------------------------------------------"+c+"========================================")
    print(b+"ye file wala he")
    for s in search.results:
        print(s['title'], s['id'],s['release_date'])
        data2=s['release_date']
        print(data2)
        x,y,z=data2.split("-")
        print(x+"yeh tmdb wala he")
        #print(b+"ttyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy")
        print(c+"==="+x)
        if str(c)==str(x):
            print(x+"yayyyyyy.......doneeee")
            print(s.similar_movies())
            
            break
        else: continue
        