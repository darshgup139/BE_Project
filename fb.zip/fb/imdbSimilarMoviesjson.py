import json
import tmdbsimple as tmdb
from dateutil import parser
from datetime import datetime, timedelta
tmdb.API_KEY = '0fee9e05c566948369b71f0cb4e6cef6'

#calculate the number of lines in the file
def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

def imdb_id(imdb_date):
    date


#return date format according to imdb
def resultant_md(movie_date):
    return parser.parse(movie_date).strftime('%Y-%m-%d')

#call len function to calculate the number of lines and print it
len=file_len("movie-fb.txt")
print(len)

#search tmdb-id of each movie 
search = tmdb.Search()
f = open('newfile.txt', 'r')
json_file = open('similar.json')
write_file = open('movie_write.txt', 'w')



#for var in list(range(len)):
json_file = open('similar.json','r')
movie_name=f.readline()
if(movie_name!="9999"):
    response = search.movie(query=movie_name)
    for s in search.results:
        fun_ret=imdb_id(s['release_date'])
        movie = tmdb.Movies(s['id'])
        response=movie.similar_movies()
        with open('similar.json', 'w') as outfile:
            json.dump(response, outfile)
            #json_file.close()
            
        j = json.load(json_file)
        json_file.close()
        egg=j['results']
        print(egg)
        for segg in egg:
            if(segg["original_language"] == 'en'):
                current_movie = segg['original_title']
               
                write_file.write(current_movie+"\n")
        write_file.write('=========================================================================')
    #json_file.close()
write_file.close()

'''
        similar_movies = segg['similar_movies']
        results = similar_movies['results']
        print(results)
        n = 5
        count = 0

        print('Similar Movies: ')
        original_titles = []
        for result in results:
            if count == n:
                break
            if result["original_language"] == 'en':
                    original_titles.append(result['original_title'])
                    count += 1

        print(original_titles)
        for title in original_titles:
            write_file.write(title+'\n')
        write_file.write('=========================================================================')
write_file.close()

'''





















        
        
