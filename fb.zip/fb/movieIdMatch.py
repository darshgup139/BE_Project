import tmdbsimple as tmdb
from dateutil import parser
from datetime import datetime, timedelta
tmdb.API_KEY = '0fee9e05c566948369b71f0cb4e6cef6'

#calculate the number of lines in the file
def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

#return date format according to imdb
def resultant_md(movie_date):
    return parser.parse(movie_date).strftime('%Y-%m-%d')

#call len function to calculate the number of lines and print it
len=file_len("newfile.txt")
print(len)

#search tmdb-id of each movie 
search = tmdb.Search()
f = open('newfile.txt', 'r')

for var in list(range(len)):
    movie_name=f.readline()
    response = search.movie(query=movie_name)
    movie_date=f.readline()
    if(movie_date=="9999"):
        pass
    else:
        date_converted=resultant_md(movie_date)
        print("date_coverted:="+date_converted)
        for s in search.results:
            date_imdb=s['release_date']
            print("date_imdb:="+date_imdb+":::::movire name::::"+s['title'])
            if str(date_converted)==str(date_imdb ):
                print("----------------similar searched------------------")
                print(s['title'])
                break    
            else:
                continue
   