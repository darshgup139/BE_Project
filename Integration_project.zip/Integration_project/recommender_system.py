import pandas as pd
import webbrowser
def getId():
    print("rating_movies")
    i=input("ENTER YOUR USER-ID:")
    webbrowser.open('http://localhost/integration_project/php_html_table_data_filter.php')
    m=input("INPUT THE MOVIE INDEX:")
    r=input("INPUT THE RATING(1-5):")
    x=i+" "+m+" " +r+" "+"xxxxxx"
    with open('u.data', 'a') as f:
        f.writelines("\n")
        f.writelines(i)
        f.writelines("\t")
        f.writelines(m)
        f.writelines("\t")
        f.writelines(r)
        f.writelines("\t")
        f.writelines("xxxxxx")
        f.close()
    m=input("INPUT THE MOVIE INDEX:")
    r=input("INPUT THE RATING(1-5):")
    x=i+" "+m+" " +r+" "+"xxxxxx"
    with open('u.data', 'a') as f:
        f.writelines("\n")
        f.writelines(i)
        f.writelines("\t")
        f.writelines(m)
        f.writelines("\t")
        f.writelines(r)
        f.writelines("\t")
        f.writelines("xxxxxx")
        f.close()
        
    r_cols = ["user_id", "movie_id", "rating"]
    ratings = pd.read_csv("u.data", sep="\t", names=r_cols,
                      usecols=range(3))
    m_cols = ["movie_id", "title"]
    movies = pd.read_csv("u.item", sep="|", names=m_cols, 
                     usecols=range(2), encoding='latin-1')
    ratings = pd.merge(movies, ratings)
    user_ratings = ratings.pivot_table(index=["user_id"], columns=["title"], values=["rating"])

    corr_matrix = user_ratings.corr(method="pearson", min_periods=100)
   
    my_ratings = user_ratings.loc[int(i)].dropna()  # select the dummy user ratings which I have added
    print("THE USER HAS MADE THE FOLLOWING RATINGS:\n", my_ratings)
    
    sim_candidates = pd.Series()
    for i in range(0, len(my_ratings)):
        sims = corr_matrix[my_ratings.index[i]].dropna()
        sims = sims.map(lambda x: x * my_ratings[i])  # We give weight values ​​given depending on the user's grading-of
        sim_candidates = sim_candidates.append(sims)
    #print(sim_candidates.get(1,default=None))
    sim_candidates.sort_values(inplace=True, ascending=False)
    sim_candidates = sim_candidates.groupby(sim_candidates.index).sum()
    sim_candidates.sort_values(inplace=True,ascending=False)
    print("\n")
    print("==========The recommendations are as follows:==========")

    topTen=sim_candidates.head(10)
    topTenList=list(topTen)

    
    for i in range(0,10):
        x=list(topTen[topTen==topTenList[i]].index)
        for t in x:
            print(t[1])



getId()