#from phpy import PHP
import webbrowser
import singmov
import recommender_system as rs
import subprocess



def menu():
    print("GET RECOMMENDED IN THE FOLLOWING WAYS:-")
    print("-------------------------------------------------------------")
    print("1. USING FACEBOOK")
    print("2. USING BASIC FILTERS")
    print("3. BY RATING MOVIES")
    x=input("I'll CHOOSE OPTION :")
    return x;
def go_again():
    z=input("Press c to continue or e to exit:")
    if(z=="c"):
        print("==============================================================================")
        x=menu()
        choosen_option(x)
    elif(z=="e"):
        exit()
    else:
        print("Error: WRONG INPUT")
        go_again()
        
    
def using_fb():
    print("using fb")
    # webbrowser.get('chrome')
    webbrowser.open('http://localhost/integration_project/index.php')
    a=input("INPUT r TO RUN THE ALGO:")
    if(a=="r"):
        singmov.main_part() 
    go_again()


def  basic_filters():
    print(" Loading...")
    import hello
    hello.mainpart()
    go_again()

def rating_movies():
    rs.getId()
    '''
    print("rating_movies")
    i=input("ENTER YOUR USER-ID:")
    webbrowser.open('http://localhost/integration_project/php_html_table_data_filter.php')
    m=input("INPUT THE MOVIE INDEX:")
    r=input("INPUT THE RATING(1-5):")
    x=i+" "+m+" " +r+" "+"xxxxxx"
    with open('u.data', 'a') as f:
        f.writelines("\n")
        f.writelines(i)
        f.writelines("\t")
        f.writelines(m)
        f.writelines("\t")
        f.writelines(r)
        f.writelines("\t")
        f.writelines("xxxxxx")
        f.close()
    m=input("INPUT THE MOVIE INDEX:")
    r=input("INPUT THE RATING(1-5):")
    x=i+" "+m+" " +r+" "+"xxxxxx"
    with open('u.data', 'a') as f:
        f.writelines("\n")
        f.writelines(i)
        f.writelines("\t")
        f.writelines(m)
        f.writelines("\t")
        f.writelines(r)
        f.writelines("\t")
        f.writelines("xxxxxx")
        f.close()
        #rs.getId(i)
    '''
'''    if(a=="r"):
        singmov.main_part() 
    go_again()
'''
    #subprocess.call("php C://xampp/htdocs/Integration_project/php_html_table_data_filter.php")
    #php_file_path="C:\\xampp\htdocs\Integration_project\php_html_table_data_filter.php"
    #php = PHP(php_file_path)
    
def choosen_option(x):
    if x == '1':
        using_fb()
    elif x == '2':
        basic_filters()
    elif x=='3':
        rating_movies()
    else:
        print("ERROR: YOU HAVE ENTERED WRONG CHOICE....PLEASE ENTER AGAIN")
        x=menu();
        choosen_option(x)
        
def main1():
    x=menu()
    choosen_option(x)

